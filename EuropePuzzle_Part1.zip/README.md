# Europe Puzzle (Kotlin)
Europe map puzzle game. APK GitHub Actions se automatically banti hai.

Build: GitHub -> Actions -> Build APK -> Artifacts -> EuropePuzzle-debug-apk
