package com.europepuzzle.game

import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(getColor(R.color.bg))
            setPadding(48, 48, 48, 48)
        }

        val title = TextView(this).apply {
            text = getString(R.string.title)
            textSize = 34f
            setTextColor(getColor(R.color.primary))
            gravity = Gravity.CENTER
        }

        val subtitle = TextView(this).apply {
            text = getString(R.string.subtitle)
            textSize = 16f
            setTextColor(getColor(R.color.text_dark))
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 64)
        }

        val startBtn = Button(this).apply {
            text = getString(R.string.start)
            setOnClickListener {
                // Part 2 me yahan se GameActivity khulegi
                Toast.makeText(
                    this@MainActivity,
                    getString(R.string.coming_soon),
                    Toast.LENGTH_SHORT
                ).show()
            }
        }

        root.addView(title)
        root.addView(subtitle)
        root.addView(startBtn)
        setContentView(root)
    }
}
